ace.define("ace/snippets/haxe",["require","exports","module"], function(require, exports, module) {
"use strict";

exports.snippetText =undefined;
exports.scope = "haxe";

});                (function() {
                    ace.require(["ace/snippets/haxe"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            